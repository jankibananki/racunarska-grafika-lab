
// IND_19728View.cpp : implementation of the CIND19728View class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "IND_19728.h"
#endif

#include "IND_19728Doc.h"
#include "IND_19728View.h"
#include <cmath>
#include <vector>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CIND19728View

IMPLEMENT_DYNCREATE(CIND19728View, CView)

BEGIN_MESSAGE_MAP(CIND19728View, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CIND19728View construction/destruction

CIND19728View::CIND19728View() noexcept
{
	// TODO: add construction code here

}

CIND19728View::~CIND19728View()
{
}

BOOL CIND19728View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

void CIND19728View::DrawPolygon(CDC* pDC, CPoint* points, int n) // znaci prosledjuje se kontekst uredjaja preko koga crtamo, pokazivac niza temena, i broj temena
{
	pDC->Polygon(points, n); //->crta i popunjava mnogougao
}

// CIND19728View drawing

void CIND19728View::DrawRegularPolygon(CDC* pDC, int cx, int cy, int r, int n, float rotAngle)
{
	//potrebno je da funkcija sama izracuna koordinate pomocu sinusa i kosinusa
	// NAPOMENA: CPP KORISTI RADIJANE NE STEPENE

	if (n < 3 || r <= 0)
		return; //ne moze da se nacrta mnogougao u ovom slucaju

	const double PI = 3.141592653589793;
	double step = 2 * PI / n; // 360 = 2pi
	double rotation = rotAngle * PI / 180;

	std::vector<CPoint> points(n);

	for (int i = 0; i < n; i++)
	{
		double alpha = i * step + rotation; // rootAngle se koristi za rotaciju, da se zarotira za odredjeni ugao
		int x = (int)round(cx + r * cos(alpha));
		int y = (int)round(cy + r * sin(alpha));

		points[i] = CPoint(x, y);
	}

	DrawPolygon(pDC, points.data(), n);
	//cx i cy su centar mnogougla
	//r je poluprecnik opisane kruznice
	//i angle ugao trenutnog temena
}

void CIND19728View::DrawGrid(CDC* pDC)
{
	CPen pen(PS_SOLID, 1, RGB(200, 200, 200));
	CPen* oldPen = pDC->SelectObject(&pen);

	for (int i = 0; i <= 500; i += 25)
	{
		pDC->MoveTo(i, 0);
		pDC->LineTo(i, 500);

		pDC->MoveTo(0, i);
		pDC->LineTo(500, i);
	}

	pDC->SelectObject(oldPen);
}

void CIND19728View::OnKeyDown(
	UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (nChar == 'G')
	{
		m_showGrid = !m_showGrid;
		Invalidate();
	}

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CIND19728View::OnDraw(CDC* pDC)
{
	CIND19728Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	int savedDC = pDC->SaveDC();
	
	CBrush brush(RGB(230, 230, 230));
	CBrush* oldBrush = pDC->SelectObject(&brush);

	pDC->Rectangle(0, 0, 500, 500);


	CPen pen(PS_SOLID, 5, RGB(255, 0, 255));
	CPen* oldPen = pDC->SelectObject(&pen);

	pDC->Rectangle(75, 25, 425, 475);

	CBrush brush1(RGB(255, 153, 204));
	CBrush* oldBrush1 = pDC->SelectObject(&brush1);

	CPoint points1[3] =
	{
		CPoint(75,25),
		CPoint(75,250),
		CPoint(190,140)
	};

	DrawPolygon(pDC, points1, 3);

	CBrush brush2(RGB(153, 0, 204));
	CBrush* oldBrush2 = pDC->SelectObject(&brush2);

	CPoint points2[4] =
	{
		CPoint(75,25),
		CPoint(200,25),
		CPoint(315,140),
		CPoint(190,140)
	};

	DrawPolygon(pDC, points2, 4);

	CBrush brush3(RGB(255, 0, 0));
	CBrush* oldBrush3 = pDC->SelectObject(&brush3);

	CPoint points3[3] =
	{
		CPoint(200,25),
		CPoint(425,25),
		CPoint(425,250)
	};

	DrawPolygon(pDC, points3, 3);

	CBrush brush4(RGB(255, 255, 0));
	CBrush* oldBrush4 = pDC->SelectObject(&brush4);

	CPoint points4[3] =
	{
		CPoint(425,250),
		CPoint(425,362),
		CPoint(313,362)
	};

	DrawPolygon(pDC, points4, 3);

	CBrush brush5(RGB(255, 165, 0));
	CBrush* oldBrush5 = pDC->SelectObject(&brush5);

	DrawRegularPolygon(pDC, 369, 417, 79, 4, 45);

	CBrush brush6(RGB(0, 255, 30));
	CBrush* oldBrush6 = pDC->SelectObject(&brush6);

	CPoint points5[3] =
	{
		CPoint(313,362),
		CPoint(313,474),
		CPoint(196,362)
	};

	DrawPolygon(pDC, points5, 3);

	CBrush brush7(HS_VERTICAL, RGB(0, 0, 255));
	pDC->SelectObject(&brush7);

	pDC->SetBkColor(RGB(255, 255, 255));
	pDC->SetBkMode(OPAQUE);

	CPoint points6[3] =
	{
		CPoint(313,474),
		CPoint(75,474),
		CPoint(75,250)
	};

	DrawPolygon(pDC, points6, 3);

	pDC->SelectStockObject(NULL_BRUSH);

	CPen pentanji(PS_SOLID, 2, RGB(255, 0, 255));
	CPen* oldPentanji = pDC->SelectObject(&pentanji);

	DrawRegularPolygon(pDC, 125, 142, 25, 6, 0);

	DrawRegularPolygon(pDC, 145, 410, 33, 4, 0);

	DrawRegularPolygon(pDC, 277, 390, 16, 8, 0);

	DrawRegularPolygon(pDC, 385, 330, 16, 7, 0);

	DrawRegularPolygon(pDC, 352, 90, 35, 5, 0);

	if (m_showGrid)
		DrawGrid(pDC);

	// TODO: add draw code for native data here
}


// CIND19728View printing

BOOL CIND19728View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CIND19728View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CIND19728View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CIND19728View diagnostics

#ifdef _DEBUG
void CIND19728View::AssertValid() const
{
	CView::AssertValid();
}

void CIND19728View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CIND19728Doc* CIND19728View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CIND19728Doc)));
	return (CIND19728Doc*)m_pDocument;
}
#endif //_DEBUG


// CIND19728View message handlers
